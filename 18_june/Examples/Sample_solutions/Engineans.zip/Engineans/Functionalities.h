#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include "Engine.h"
void Createobjects(Engine **arr,int N);
void DisplayObjects(Engine **arr,int N);
 float Averagehorsepower(Engine **arr,int N);
 float FindTorqueById(Engine **arr,int N,int id);
 float FoundHorsePowerForTorqueEngine(Engine **arr,int N);
#endif // FUNCTIONALITIES_H
